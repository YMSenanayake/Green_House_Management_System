import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
      <h1 className='bg-blue-400 '> ITP PROJECT</h1>
    </div>
  );
}

export default App;
